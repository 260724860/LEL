﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chanjet.TP.OpenAPI
{ 
    public enum PostDataFormatEnum
    {
        FormUrlEncoded,
        Json,
        Mutil
    }
}
